 long int xxx=1234;
unsigned short read()
{
unsigned short kp;
 do
      {
      kp = Keypad_Released();
      Delay_ms(10);
          }
          while (!kp);
    kp-=1;
    return(kp);
    }
     

 void main()
 {    long int pin=0;
 unsigned short kpp=0,cnt=0;
 TRISB = 0;
 TRISC=0;
 PORTC=0;
 Keypad_Init(&PORTD);
  Lcd_Init(&PORTB);         // Initialize LCD on PORTC
  Lcd_Cmd(LCD_CLEAR);       // Clear display
  Lcd_Cmd(LCD_CURSOR_OFF);
  Lcd_Out_Cp("    WELCOME");
  Delay_ms(800);
    while(cnt!=1)
 {
  Lcd_Cmd(LCD_CLEAR);       // Clear display
  Lcd_Out_Cp("* Enter PIN *");
  Lcd_Cmd(LCD_SECOND_ROW);
   Lcd_Cmd(LCD_BLINK_CURSOR_ON);
   
 while (kpp<10)
{  pin=pin*10+ kpp;
kpp=read();
if (kpp<10)
{    Lcd_Chr_Cp('*'); }
}

if(pin==xxx)
{       Lcd_Cmd(LCD_CLEAR);       // Clear display
  Lcd_Cmd(LCD_CURSOR_OFF);
  Lcd_Out_Cp("OK");
  PORTC=1;
  cnt=1;
  }
 else
 { Lcd_Cmd(LCD_CLEAR);       // Clear display
  Lcd_Cmd(LCD_CURSOR_OFF);
  Lcd_Out_Cp("PIN INCORRECT");
   Delay_ms(250);
   Lcd_Cmd(LCD_CLEAR);
   Delay_ms(250);
    Lcd_Out_Cp("PIN INCORRECT");
       Delay_ms(250);
       kpp=0;
       }
       pin=0;
 }
 }


  
 
    

