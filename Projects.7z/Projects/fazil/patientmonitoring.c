unsigned int temp;
char text[4];
void main()
{


  ADCON1 = 0x85;
  TRISA = 0xFF;
  TRISB = 0;                  // PORTB is output
  TRISC = 0;
  Lcd8_Init(&PORTB, &PORTC);  // Initialize LCD at PORTB and PORTC
  Lcd8_Cmd(LCD_CURSOR_OFF);   // Turn off cursor
  do
  {
  Lcd8_out(1, 1, "Temp");
  temp = Adc_Read(0)/2;
  ByteToStr(temp, text);
  Lcd8_Out(1, 7, text);       // Print text on LCD
  TMR0 = 0;
  OPTION_REG.F5 = 1;
  OPTION_REG.F4 = 0;
  OPTION_REG.F3 = 0;
  OPTION_REG.F2 = 0;
  OPTION_REG.F1 = 0;
  OPTION_REG.F0 = 0;
  delay_ms(5000);
  TMR0 = TMR0 * 24;
  bytetostr(TMR0, text);
  Lcd8_out(2, 1, "HB");
  Lcd8_out(2, 7, text);
  delay_ms(1000);
 }while(1);
}