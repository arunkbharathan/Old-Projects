//unsigned short fix=1500;
int zzz,b,a;
char text[13];
unsigned float res,res1,res2;



void main() {
delay_ms(200);
TRISC=0x7f;
TRISD=0x00;
TRISB=0x00;
PORTD=0;

 CCP1CON=0;
 INTCON=0;
 PIE1=0;
lcd_init(&PORTB);
Lcd_Cmd(Lcd_CLEAR);
Lcd_Cmd(Lcd_CURSOR_OFF);
Lcd_Out(1,1, "CURRENT RPM");
 while(1)
{

asm{bsf PORTC,7}



 T1CON =0X30;
  PIR1=0;


TMR1H=0;
TMR1L=0;


 CCP1CON=0x05;
T1CON =0x31;

asm{bcf PORTC,7}
delay_ms(500);
}

}