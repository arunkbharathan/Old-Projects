int y=0;
void main()

{
        OPTION_REG=0;
       ADCON0=0X49;
      ADCON1 = 0x82;
     INTCON = 0;
    TRISA = 0xFF;
    PORTA=0x00;
   TRISB = 0;
 PORTB=0x00;
  delay_ms(500);
while(1)
   {
     y = adc_read(0);
     if(y>=613)
{ delay_ms(250);
y = adc_read(0);
 if(y>=306)
 {PORTB=0x01;
 delay_ms(20000);
 PORTB=0x00;
 }
}
delay_ms(5);
 }
 }