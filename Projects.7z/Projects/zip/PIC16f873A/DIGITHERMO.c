           #include"built_in.h"
          int y,i=0;
          float n4;
          char a[13];

void name()
{
   char a[]="Naser";
   char b[]="Abu";
   char v[]="Arun";
   char j[]="Geejo";
    lcd_out(1,1,a);
    lcd_out(1,9,b);
    lcd_out(2,1,v);
    lcd_out(2,9,j);
    delay_ms(2000);
    portb=0xA0;
}

 void disp()
 {
    portb=0x8a;
    lcd_out_Cp("Digital");
    Lcd_Cmd(LCD_SECOND_ROW);
    Lcd_Out_Cp("Thermometer");

    Delay_ms(2000);
    Lcd_Cmd(lcd_clear);
    Lcd_Out_Cp("S6 ECE-A  2009");
    Delay_ms(2000);
       Lcd_Cmd(lcd_clear);
    Lcd_Out_Cp("Submitted By");
     Delay_ms(2000);
    Lcd_Cmd(lcd_clear);
    }
 void disp2()
 {
    lcd_cmd(lcd_clear);
    Lcd_Out_Cp("Degree Celsius");

   }

void main()

{   void name();
  void disp();
  void disp2();
      OPTION_REG=0;
      ADCON0=0X49;
  ADCON1 = 0x82;
    INTCON = 0;
    TRISA = 0xFF;
   TRISB = 0;
  trisc = 0;
  portb=0x00;
  Lcd_Config(&PORTc, 0, 2, 1, 7, 6, 5, 4);
     lcd_cmd(lcd_clear);
    Lcd_Cmd(Lcd_CURSOR_OFF);
     disp();
     name();
     disp2();
while(1)
   {
     y = adc_read(1);
     if(y<=0||y>=310)
     {portb=0xaa;
     lcd_cmd(lcd_clear);
      Lcd_Out_Cp("CHECK LM35");
      delay_ms(6000);
      disp2();
}
      portb=0xa0;
     while (y!=i)
     {  if (y>i)
     {portb=0xA8;}
     if (y<i)
     {portb=0xA2;}
     n4 = y*5;
      n4=n4/1023;
      n4=n4*100;
      floatToStr(n4,a);
      lcd_out(2,8,a);
       i=y;
 }
        delay_ms(66);
     }
}
