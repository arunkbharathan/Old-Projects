int zzz,b,a;
char text[13];
unsigned float res,res1,res2;



void main() {
delay_ms(500);
TRISC=0x7f;
TRISD=0x00;
TRISB=0x00;
PORTD=0;

 CCP1CON=0;
 INTCON=0;
 PIE1=0;
Lcd_Init(&PORTB);
Lcd_Cmd(Lcd_CLEAR);
Lcd_Cmd(Lcd_CURSOR_OFF);
Lcd_Out(1,1, "CURRENT RPM");
 while(1)
{   CCP1CON=0;
asm{bsf PORTC,7}
 T1CON =0X30;
  PIR1=0;


TMR1H=0;
TMR1L=0;


 CCP1CON=0x05;
T1CON =0x31;


while(!(PIR1.CCP1IF))
{}






PIR1.CCP1IF=0;
res1=CCPR1H*256+CCPR1L;


while(!(PIR1.CCP1IF))
{}


PIR1.CCP1IF=0;
if(PIR1.TMR1IF==1)
{   PIR1.TMR1IF=0;
res2=CCPR1H*256+CCPR1L+65536;
}
else
{  res2=CCPR1H*256+CCPR1L;}


res=(res2-res1);
res=abs(res);
res=1/(res*8*0.000001);
res=res*60;

floattostr(res,text);
Lcd_Out(2, 1, text);
zzz=res;
a=abs((zzz-1500));
if(zzz==1500)
   {portd=0; goto ab;}
if(zzz<1500)
 {portd=0x02;}
 if(a>750)
 {b=1;goto ac;}
 if(a>500)
 {b=2;goto ac;}
 if(a>375)
 {b=3;goto ac;}
 if(a>300)
 {b=4;goto ac;}
 if(a>250)
 {b=5;goto ac;}
 if(a>215)
 {b=6;goto ac;}
 if(a<215)
 {b=7;}


  ac:

if(b==1)
{portd=0b00011101;}

if(b==2)
{portd=0b00001101;}

if(b==3)
{portd=0b00010101;}
if(b==4)
{portd=0b00011001;}

if(b==5)
{portd=0b00000101; }
if(b==6)
{portd=0b00001001;  }

if(b==7)
{portd=0b00010001;}



if(zzz<1500)
 {asm{bsf PORTD,1}}
 ab:
 asm{bcf PORTC,7}
delay_ms(100);
}

}