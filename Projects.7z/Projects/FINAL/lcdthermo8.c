           #include"built_in.h"
          int y,i=0;
          float n2,n3,n1,n4;
          char a[13];

void name()
{
   char a[]="Naser";
   char b[]="Abu";
   char v[]="Arun";
   char j[]="Geejo";
    lcd_out(1,1,a);
    lcd_out(1,9,b);
    lcd_out(2,1,v);
    lcd_out(2,9,j);
    delay_ms(2000);
    portd=0x81;
}

 void disp()
 {
    portd=0x13;
    lcd_out_Cp("Digital");
    Lcd_Cmd(LCD_SECOND_ROW);
    Lcd_Out_Cp("Thermometer");

    Delay_ms(2000);
    Lcd_Cmd(lcd_clear);
    Lcd_Out_Cp("S6 ECE-A  2009");
    Delay_ms(2000);
    Lcd_Cmd(lcd_clear);
    }
 void disp2()
 {
    lcd_cmd(lcd_clear);
    Lcd_Out_Cp("      C      F");
   Lcd_Cmd(LCD_SECOND_ROW);
   Lcd_Out_Cp("      K      R");
   }

void main()

{   void name();
  void disp();
  void disp2();
      ADCON0=0X49;
  ADCON1 = 0x82;
    INTCON = 0;
    TRISA = 0xFF;
   TRISB = 0;
  TRISd = 0;
  portd=0x00;
  Lcd_Init(&PORTb);
     lcd_cmd(lcd_clear);
    Lcd_Cmd(Lcd_CURSOR_OFF);
     disp();
     name();
     disp2();
while(1)
   {
     y = adc_read(1);
     if(y<0||y>320)
     {portd=0x93;
     lcd_cmd(lcd_clear);
      Lcd_Out_Cp("CHECK LM35");
      delay_ms(6000);
      disp2();
}
      portd=0x81;
     while ((i!=y)&&(i!=(y+1))&&(i!=(y-1)))
     {  if (y>i)
     {portd=0x83;}
     if (y<i)
     {portd=0x91;}
     n4 = y*5;
      n4=n4/1023;
      n4=n4*100;
      intToStr(n4,a);
      lcd_out(1,1,a);
        n2=(n4*9/5 + 32);
        n3=(n2+460.67);
        inttostr(n3,a);
       lcd_out(2,8,a);
       inttostr(n2,a);
       lcd_out(1,8,a);
        n1=n4+273.16;
       inttostr(n1,a);
       lcd_out(2,1,a);
     i=y;
 }
        delay_ms(20);
     }
}
