unsigned short cnt=0,kp=0;
long double tim;
char a[13];

void interrupt() {
   cnt++;                   // Increment value of cnt on every interrupt
  TMR0   = 00;
  INTCON = 0x20;           // Set T0IE, clear T0IF
}

void main() {

    Lcd_Init(&PORTC);
   Lcd_Cmd(Lcd_CLEAR);       // Clear display
  Lcd_Cmd(Lcd_CURSOR_OFF);  // Turn cursor off
   Keypad_Init(&PORTD);
  //  PORTB = 0xF0;               // Initialize PORTB
  //TRISB = 0;                  // PORTB is output
  T1CON = 1;                  // Timer1 settings
  PIR1.TMR1IF = 0;            // clear TMR1IF
  TMR1H = 0x00;               // Initialize Timer1 register
  TMR1L = 0x00;
  PIE1.TMR1IE  = 1;           // enable Timer1 interrupt

 while(1){


       do
      {
      kp = Keypad_Released();
    //  Delay_ms(10);
          }
          while (!kp);

    OPTION_REG=0b10000111;
    
    do
      {
      kp = Keypad_Released();
    //  Delay_ms(10);
          }
          while (!kp);

     OPTION_REG=0b10100111;
     
  tim=((cnt*256)+TMR0)*(0.000256);
  TMR0=255;
  inttostr(tim,a);
  Lcd_Out(2, 1, a);
  Lcd_Out_Cp("Here!");
  delay_ms(70);
  break;
   //Lcd_Cmd(Lcd_CLEAR);
  }
  
  }
