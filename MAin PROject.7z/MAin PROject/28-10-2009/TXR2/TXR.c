unsigned short temp_res,kp;

void main() {
  USART_Init(19200);              // Initalize USART (19200 baud rate, 1 stop bit, no parity...)

     // Keypad_Init(&PORTB);
      
       temp_res = 0x00;
       trisa=0x00;

  do {
            // do{
    //  kp = Keypad_Released();
                  //    }
   // while (!kp);

    PORTA= temp_res;
    temp_res = ~temp_res;  // Read 10-bit ADC from AN2 and discard 2 LS bits
    USART_Write(temp_res);        // Send ADC reading as byte

    Delay_ms(1000);



  } while (1);                    // endless loop
}

