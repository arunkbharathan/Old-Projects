/*
 * Project name:
     ADC_USART (Transferring ADC data on Serial port)
 * Copyright:
     (c) MikroElektronika, 2005-2008.
 * Description:
     The code performs AD conversion and sends results (the upper 8 bits) via
     USART.
 * Test configuration:
     MCU:             PIC16F887
     Dev.Board:       EasyPIC5
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v8.0
 * NOTES:
     None.
*/

unsigned short temp_res;

void main() {
  USART_Init(19200);              // Initalize USART (19200 baud rate, 1 stop bit, no parity...)


  TRISB  = 0;
  PORTB=0;


  do {
  
      if (Usart_Data_Ready()) {   // If data is received
      temp_res = Usart_Read();         // Read the received data
      PORTB=temp_res;

    }

  
  
  
  


  } while (1);                    // endless loop
}





