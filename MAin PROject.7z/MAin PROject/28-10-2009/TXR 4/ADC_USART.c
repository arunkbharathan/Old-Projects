/*
 * Project name:
     ADC_USART (Transferring ADC data on Serial port)
 * Copyright:
     (c) MikroElektronika, 2005-2008.
 * Description:
     The code performs AD conversion and sends results (the upper 8 bits) via
     USART.
 * Test configuration:
     MCU:             PIC16F887
     Dev.Board:       EasyPIC5
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v8.0
 * NOTES:
     None.
*/

unsigned short temp_res;

void main() {
  USART_Init(2400);              // Initalize USART (19200 baud rate, 1 stop bit, no parity...)
    TRISB=0;
   temp_res=0;

  do {    PORTB=temp_res;
        temp_res=~temp_res;
        
    USART_Write(temp_res);        // Send ADC reading as byte
    Delay_ms(500);
  } while (1);                    // endless loop
}

