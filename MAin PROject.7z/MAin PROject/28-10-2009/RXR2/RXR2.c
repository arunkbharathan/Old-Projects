unsigned short temp_res;

void main() {
               // Initalize USART (19200 baud rate, 1 stop bit, no parity...)


  TRISB  = 0;

  TRISC=0;



  do {
   PORTC=255;
   PORTB=0x00;
   delay_ms(1000);
  PORTB=0xff;
   PORTC=0;
   




  } while (1);                    // endless loop
}



