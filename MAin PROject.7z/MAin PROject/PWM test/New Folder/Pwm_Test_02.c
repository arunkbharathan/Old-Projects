/*
 * Project name:
     PWM1_Test_01 (PWM1 library Demonstration)
 * Copyright:
     (c) MikroElektronika, 2005-2008.
 * Description:
     This is a simple demonstration of PWM1 library, which is being used for
     control of the PIC's CCP module. The module is initialized and started,
     after which the PWM1 Duty Ratio can be adjusted by means of two buttons
     connected to pins RA0 and RA1. The changes can be monitored on the CCP
     output pin (RC2).
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       EasyPIC4
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:     -
     SW:              mikroC v8.0.0.0
 * NOTES:
     - Pull-down PORTA and connect button jumper (jumper17) to Vcc.
     - To verify hold down RA0 or RA1 and watch the LEDs.
*/

unsigned  k;
unsigned short num;
void InitMain() {

  PWM1_Init(192000);                    // Initialize PWM1 module at 5KHz
  TRISB=0;
  PORTB=0;
}

void main() {
  initMain();

   ADCON0=0b10000001;
  ADCON1=0x0e;
 PWM1_Start();                       // start PWM1

  while (1) {                         // endless loop

   k= Adc_Read(0);
  // delay_us(105);
    num=k>>2;
  Pwm_Change_Duty(num);
 //       PORTB=k;
  }
}

