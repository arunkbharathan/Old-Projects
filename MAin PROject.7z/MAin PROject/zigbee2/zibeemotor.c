void main(){
unsigned short a,c;
Usart_init(9600); // initail USART


TRISB=0;
PORTB=255;
 ADCON1     = 0x02;                       // configure VDD as Vref, and analog channels

  ADCON0=0b10000001;
  TRISA      = 0xFF;                       // designate PORTA as input
delay_ms(500);
PORTB=0;
do{
a=adc_read(0);
while(a>200)
{Usart_Write(a);
c=1;
a=adc_read(0);}
if(c==1)
{Usart_Write(0);
c=0;}

}while(1);








}