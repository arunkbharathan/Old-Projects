void main(){
unsigned short  a;

TRISB = 0;
  PORTB=255;
Usart_init(9600); // initail USART

delay_ms(500);
PORTB=0;
 a=0;
do{
if(Usart_Data_Ready())
{   a=Usart_Read();
if(a>200)
PORTB=255;
else
PORTB=0;
}

}while(1);

}