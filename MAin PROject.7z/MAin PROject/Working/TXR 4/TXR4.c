void Print_str(char *txt){
while(*txt) Usart_Write(*(txt++));
}
void delay100(){
delay_ms(100);
}

void main(){

TXSTA.TXEN = 1;

Usart_init(9600); // initail USART

//Code for sender
Usart_Write('X');
delay_ms(1500);
Print_str("+++"); //enter AT command mode
delay_ms(2000);
Print_str("ATID3456"); //PAN ID
Usart_Write(13);
delay100();
Print_str("ATBD03"); //9600 baud
Usart_Write(13);
delay100();

Print_str("ATMY01"); //my address 1
Usart_Write(13);
delay100();
Print_str("ATDL02"); //destination address 2
Usart_Write(13);
delay100();
Print_str("ATRO00"); //1 byte packetization
Usart_Write(13);
delay100();


Print_str("ATWR"); //write settings to firmware
Usart_Write(13);
delay100();
delay_ms(2000);

Print_str("ATCN"); //exit command mode
Usart_Write(13);
delay100();

delay_ms(2000);

TRISB=0;


do{
PORTB='1';
Usart_Write(PORTB);
delay_ms(500);
 PORTB='2';
  Usart_Write(PORTB);
  delay_ms(500);
  PORTB='3';
  Usart_Write(PORTB);
   delay_ms(500);
    PORTB='4';

  Usart_Write(PORTB);
  delay_ms(500);
     PORTB='5';

  Usart_Write(PORTB);
   delay_ms(500);
     PORTB='6';

  Usart_Write(PORTB);
  delay_ms(500);
  PORTB='7';

  Usart_Write(PORTB);
 delay_ms(500);
}while(1);








}