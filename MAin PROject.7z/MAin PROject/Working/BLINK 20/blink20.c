void main()
{
TRISC=0;
TRISB=0;
TRISA=0;
PORTA=0;
PORTB=0;
PORTC=0;
do{
delay_ms(500);
PORTA=~PORTA;
delay_ms(500);
PORTB=~PORTB;
delay_ms(500);
PORTC=~PORTC;
}
while(1);
}