void Print_str(char *txt){
while(*txt) Usart_Write(*(txt++));
}
void delay100(){
delay_ms(100);
}

void main(){
char a;

TRISB = 0;                // PORTB is output
  Lcd_Init(&PORTB);         // Initialize LCD connected to PORTB
  Lcd_Cmd(Lcd_CLEAR);       // Clear display
  Lcd_Cmd(Lcd_CURSOR_OFF);  // Turn cursor off
  


TXSTA.TXEN = 1;

Usart_init(9600); // initail USART

Usart_Write('X');
delay_ms(1500);
Print_str("+++");
delay_ms(2000);
Print_str("ATID3456"); //PAN ID
Usart_Write(13);
delay100();
Print_str("ATBD03"); //9600 baud
Usart_Write(13);
delay100();
Print_str("ATMY02"); //my address 2
Usart_Write(13);
delay100();
Print_str("ATDL01"); //destination address 1
Usart_Write(13);
delay100();
Print_str("ATRO00"); //1 byte packetization
Usart_Write(13);
delay100();


Print_str("ATWR"); //write settings to firmware
Usart_Write(13);
delay100();
delay_ms(2000);

Print_str("ATCN"); //exit command mode
Usart_Write(13);
delay100();

delay_ms(2000);



 Lcd_Out(1, 1, "Waiting For Data");
  delay_ms(1000);

do{
if (Usart_Data_Ready())
{a = Usart_Read();}

 //inttostr(receive,a);
Lcd_Chr_Cp(a);
}while(1);

}