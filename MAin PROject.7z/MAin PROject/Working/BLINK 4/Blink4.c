void main()
{

TRISC=0;

PORTC=0;

do{
delay_ms(500);


PORTC=~PORTC;


}
while(1);
}