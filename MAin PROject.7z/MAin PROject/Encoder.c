/* Table of index changes */
unsigned short  int IndexTable[16] = {
    0xff, 0xff, 0xff, 0xff, 2, 4, 6, 8,
    0xff, 0xff, 0xff, 0xff, 2, 4, 6, 8
};
/* Quantizer step size lookup table */
unsigned short int StepSizeTable[39] = {
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
    19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
    50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
    130, 143, 157, 173, 190, 209, 230, 255 };
signed short int diff;               /* Difference between sample and predicted sample */
unsigned short int step;                      /* Quantizer step size */
signed short int predsample;         /* Output of ADPCM predictor */
signed short int prevsample;
signed short int diffq;              /* Dequantized predicted difference */
unsigned short int index;                      /* Index into step size table */
unsigned short int previndex;

/*****************************************************************************
*       ADPCMEncoder - ADPCM encoder routine                                 *
******************************************************************************
*       Input Variables:                                                     *
*               signed long sample - 16-bit signed speech sample             *
*       Return Variable:                                                     *
*               char - 8-bit number containing the 4-bit ADPCM code          *
*****************************************************************************/
unsigned short ADPCMEncoder( signed short int sample )
{
unsigned short int code;               /* ADPCM output value */
unsigned short int tempstep;           /* Temporary step size */
/* Restore previous values of predicted sample and quantizer step
   size index
*/

predsample = prevsample;
index = previndex;
step = StepSizeTable[index];
/* Compute the difference between the actual sample (sample) and the
   the predicted sample (predsample)
*/
diff = sample - predsample;
if(diff >= 0)
code = 0;
else
{
code = 8;
diff = -diff;
}
/* Quantize the difference into the 4-bit ADPCM code using the
   the quantizer step size
*/
tempstep = step;
if( diff >= tempstep )
{
code |= 4;
diff -= tempstep;
}
tempstep >>= 1;
if( diff >= tempstep )
{
code |= 2;
diff -= tempstep;
}
tempstep >>= 1;
if( diff >= tempstep )
code |= 1;
/* Inverse quantize the ADPCM code into a predicted difference
   using the quantizer step size
*/

diffq = step >> 3;
if( code & 4 )
diffq += step;
if( code & 2 )
diffq += step >> 1;
if( code & 1 )
diffq += step >> 2;
/* Fixed predictor computes new predicted sample by adding the
   old predicted sample to predicted difference
*/
if( code & 8 )
predsample -= diffq;
else
predsample += diffq;
/* Check for overflow of the new predicted sample
*/
if( predsample > 127 )
predsample = 127;
else if( predsample < -128 )
predsample = -128;
/* Find new quantizer stepsize index by adding the old index
   to a table lookup using the ADPCM code
*/
index += IndexTable[code];
/* Check for overflow of the new quantizer step size index
*/
if( index < 0 )
index = 0;
if( index > 38 )
index = 38;
/* Save the predicted sample and quantizer step size index for
   next iteration
*/
                   prevsample = predsample;
                      previndex = index;
/* Return the new ADPCM code */
return 0;
}


void main() {



  do {
        ADPCMEncoder(-100);
        ADPCMEncoder(+100);
        

    } while (1);
}
