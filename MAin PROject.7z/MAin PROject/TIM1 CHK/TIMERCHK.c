void interrupt() {

  PIR1.TMR1IF = 0;            // clear TMR1IF
   TMR1H = 0xFD;               // Initialize Timer1 register
  TMR1L = 0x7F;
  PORTB=~PORTB;
}

void main() {
   TRISB=0;
   PORTB=0;
  T1CON = 0b00000001;                  // Timer1 settings
  PIR1.TMR1IF = 0;            // clear TMR1IF
  TMR1H = 0xFD;               // Initialize Timer1 register
  TMR1L = 0x7F;
  PIE1.TMR1IE  = 1;           // enable Timer1 interrupt


  INTCON = 0xC0;              // Set GIE, PEIE

  do {

    } while (1);
}
