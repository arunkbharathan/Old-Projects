void main(){
 unsigned b;
char  a[6],c;
unsigned short num;
TRISB = 0;
  PORTB=255;
  delay_ms(500);
TRISA=255;
PORTB=0;
ADCON0=0b10000001;
ADCON1=0b00000010;
Usart_init(9600); // initail USART
Lcd_Init(&PORTB);

do{
if(Usart_Data_Ready())
{     c= Usart_Read();
      if(c<31)
 {  PORTB=c;}
     if(c>31)
   { b=Adc_Read(0);
       num=b>>2;
    num=(num*5*100)/255;
       inttostr(num,a);
     Lcd_Out(1, 1, a);
   Usart_Write(num);
   }
}

}

while(1);

}