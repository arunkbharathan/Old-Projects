#include "built_in.h"
void main()
{
      unsigned short v,t=1,num;
      char  a[7];
TRISB = 0;                // PORTB is output
  Lcd_Init(&PORTB);         // Initialize LCD connected to PORTB
  Lcd_Cmd(Lcd_CLEAR);       // Clear display
  Lcd_Cmd(Lcd_CURSOR_OFF);  // Turn cursor off
   ADCON0=0b10000001;
  ADCON1=0b00000110;
  TRISA=0xff;
  Usart_Init(9600);
 Lcd_Out_Cp("Start");
 while(1){

            while(1)  {
            if(Button(&PORTA, 0, 1, 1))
    {Usart_Write('t');break; /*Temperature*/}
    if(Button(&PORTA, 1, 1, 1))
    {Usart_Write(10); /*Reverse*/}
      if(Button(&PORTA, 2, 1, 1))
    {Usart_Write(5);;  /*Forward*/}
    if(Button(&PORTA, 3, 1, 1))
    {Usart_Write(9); /*Left or Right*/}
    if(Button(&PORTA, 4, 1, 1))
    {Usart_Write(6); /*Right or Left*/}
      if(Button(&PORTA, 5, 1, 1))
    {Usart_Write(0); /*Immediate Stop*/}

     delay_ms(200);                                 }
      delay_ms(200);
while(1)  {
     if(Usart_Data_Ready())
{          v=Usart_Read();
inttostr(v,a);
Lcd_Cmd(Lcd_CLEAR);
     Lcd_Out(1, 1, a);
     break;
     }
  } }}
