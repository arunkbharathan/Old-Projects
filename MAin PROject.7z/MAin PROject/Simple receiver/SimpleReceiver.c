/* Table of index changes */
const int IndexTable[16] = {
0xff, 0xff, 0xff, 0xff, 2, 4, 6, 8,
0xff, 0xff, 0xff, 0xff, 2, 4, 6, 8
};
/* Quantizer step size lookup table */
const long StepSizeTable[39] = {
7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
130, 143, 157, 173, 190, 209, 230, 255
};
unsigned short int step; /* Quantizer step size */
signed short int predsample; /* Output of ADPCM predictor */
signed short int diffq; /* Dequantized predicted difference */
unsigned short int index; /* Index into step size table */
signed short int prevsample;
unsigned short int previndex;
/*****************************************************************************
* ADPCMDecoder - ADPCM decoder routine *
******************************************************************************
* Input Variables: *
* char code - 8-bit number containing the 4-bit ADPCM code *
* Return Variable: *
* signed long - 16-bit signed speech sample *
*****************************************************************************/
signed short int ADPCMDecoder(unsigned short int code )
{
/* Restore previous values of predicted sample and quantizer step
size index
*/
predsample = prevsample;
index = previndex;
/* Find quantizer step size from lookup table using index
*/
step = StepSizeTable[index];
/* Inverse quantize the ADPCM code into a difference using the
quantizer step size
*/
diffq = step >> 3;
if( code & 4 )
diffq += step;
if( code & 2 )
diffq += step >> 1;
if( code & 1 )
diffq += step >> 2;
/* Add the difference to the predicted sample
*/
if( code & 8 )
predsample -= diffq;
else
predsample += diffq;
/* Check for overflow of the new predicted sample
*/
if( predsample > 127 )
predsample = 127;
else if( predsample < -128 )
predsample = -128;
/* Find new quantizer step size by adding the old index and a
table lookup using the ADPCM code
*/
index += IndexTable[code];
/* Check for overflow of the new quantizer step size index
*/
if( index < 0 )
index = 0;
if( index > 38 )
index = 38;
/* Save predicted sample and quantizer step size index for next
iteration
*/
prevsample = predsample;
previndex = index;
/* Return the new speech sample */
return( predsample );
}





void main() {

  // Initialize USART module (8 bit, 2400 baud rate, no parity bit..)
   unsigned short int y;
   signed short int song;
//  Usart_Init(113636);
  TRISB=0;
   PORTB=0;


  do {
    //if (Usart_Data_Ready()) {   // If data is received
      y = 7;//Usart_Read();         // Read the received data
      delay_ms(1000);
      PORTB=ADPCMDecoder(y);
      delay_ms(1000);
       y=7;
       PORTB=ADPCMDecoder(y);
       delay_ms(1000);
       y=7;
       PORTB=ADPCMDecoder(y);
       delay_ms(1000);
       y=8;
       PORTB=ADPCMDecoder(y);
        delay_ms(1000);
        y=0;
       PORTB=ADPCMDecoder(y);
        delay_ms(1000);
        y=8;
       PORTB=ADPCMDecoder(y);
        delay_ms(1000);
         y=0;
       PORTB=ADPCMDecoder(y);
        delay_ms(1000);
        y=8;
       PORTB=ADPCMDecoder(y);
        delay_ms(1000);
        
 //   }
 
  } while (1);
}//~!