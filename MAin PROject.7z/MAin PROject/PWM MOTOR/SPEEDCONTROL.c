       #include "built_in.h"
signed short k;

void InitMain() {

  PWM1_Init(5000);                    // Initialize PWM1 module at 5KHz
    ADCON0=0b10000001;
  ADCON1=0b00001110;
  TRISB=0b11110000;
  PORTB=0x00;
  TRISA=0xff;
}

void main() {
  initMain();


  PWM1_Start();
   while(1){
           k= Adc_Read(0);
    if(Button(&PORTA, 1, 1, 1))
    {PORTB=0b00001010; /*Reverse*/}
      if(Button(&PORTA, 2, 1, 1))
    {PORTB=0b00000101;  /*Forward*/}
    if(Button(&PORTA, 3, 1, 1))
    {PORTB=0b00001001; /*Left or Right*/}
    if(Button(&PORTA, 4, 1, 1))
    {PORTB=0b00000110; /*Right or Left*/}
      if(Button(&PORTA, 5, 1, 1))
    {PORTB=0b00000000; /*Immediate Stop*/}

delay_ms(1);
   Pwm_Change_Duty(k);
   }
   }