/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20080930:
       - initial release;
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     PORTA, PORTB, PORTC and PORTD.
 * Test configuration:
     MCU:             PIC16F887
     Dev.Board:       EasyPIC5
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
 * NOTES:
     - Turn ON the PORTB, PORTC and PORTD LEDs at SW6. (board specific)
*/
char counter;
     int COUNT;
     int sound;

void wait() {
  Delay_ms(100);
}

void main() {

  ANSEL  = 0;      // Configure AN pins as digital
  ANSELH = 0;
  C1ON_bit = 0;    // Disable comparators
  C2ON_bit = 0;

  TRISB = 0x00;    // set direction to be output
  TRISC = 0x00;    // set direction to be output
  TRISD = 0x00;    // set direction to be output

  PORTB = 0x00;    // turn OFF the PORTD leds
  PORTC = 0x00;    // turn OFF the PORTC leds
  PORTD = 0x00;    // turn OFF the PORTD leds
  while (1) {
    for (counter = 0; counter < 10; counter++){

PORTB = PORTB + COUNTER;
for (COUNT = 0;COUNT<10;COUNT++)
{      PORTD=PORTD + COUNT;
wait();
PORTD = 0X00;   }

    for (sound = 50;sound>=0;sound--)
    {PORTc=0x80;
    delay_us(500);
    portc=0x00;
    delay_us(500);
    }
     PORTB = 0x00;
    }

   /* counter = 0;
    while (counter < 8) {
      PORTB &= ~(1 << counter);
      PORTC &= ~(1 << counter);
      PORTD &= ~(1 << counter);
      wait();
      counter++;
    }*/
  }
}
